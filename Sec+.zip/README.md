# Security+ Exam Prep - 10 Day Study Program

An interactive web application to help you pass the CompTIA Security+ exam in just 10 days with focused 3-4 hour daily study sessions.

![Security+ Prep](https://img.shields.io/badge/CompTIA-Security%2B-red)
![Study Time](https://img.shields.io/badge/Study%20Time-3--4%20hrs%2Fday-blue)
![Duration](https://img.shields.io/badge/Duration-10%20Days-green)

## 🎯 Features

- **10-Day Structured Study Plan** - Comprehensive coverage of all Security+ exam domains
- **Progress Tracking** - Visual indicators for daily and overall completion
- **Interactive Checklist** - Track videos watched, practice exams, and Pocket Prep questions
- **Video Resources** - Curated links to top YouTube channels (Inside Cloud & Security, Professor Messer)
- **Trick Question Decoder** - Learn to identify and answer tricky exam questions
- **Exam Cheat Sheet** - Quick reference for ports, protocols, encryption, and attack types
- **Daily Practice Exams** - 50-90 questions per day based on that day's topics
- **Beautiful UI** - Modern, gradient design that's easy on the eyes during long study sessions

## 📚 Study Plan Overview

| Day | Topic | Study Hours | Practice Questions |
|-----|-------|-------------|-------------------|
| 1 | Security Fundamentals & CIA Triad | 3-4 hrs | 50 |
| 2 | Threats, Attacks & Vulnerabilities | 3-4 hrs | 60 |
| 3 | Architecture & Design | 4 hrs | 65 |
| 4 | Implementation - Part 1 | 3-4 hrs | 55 |
| 5 | Implementation - Part 2 | 3-4 hrs | 60 |
| 6 | Operations & Incident Response | 4 hrs | 65 |
| 7 | Governance, Risk & Compliance | 3-4 hrs | 60 |
| 8 | Cryptography Deep Dive | 4 hrs | 70 |
| 9 | Review & Weak Areas | 4 hrs | 75 |
| 10 | Final Prep & Mock Exam | 3-4 hrs | 90 |

## 🚀 Quick Start

### Option 1: Run Locally (Easiest)

1. Download this repository
2. Open `index.html` in your web browser
3. Start studying!

### Option 2: Run with Development Server

If you want to make modifications:

```bash
# Clone the repository
git clone https://github.com/YOUR-USERNAME/security-plus-prep.git
cd security-plus-prep

# Open with a local server (if you have Python installed)
python -m http.server 8000

# Or use Node.js
npx serve

# Open your browser to http://localhost:8000
```

## 📖 How to Use

1. **Start on Day 1** - Click the Day 1 button to begin your journey
2. **Watch Videos** - Follow the recommended YouTube tutorials
3. **Complete Checklist** - Check off each task as you complete it
4. **Practice Questions** - Use Pocket Prep app for daily questions
5. **Review Trick Questions** - Learn exam strategies and common traps
6. **Reference Cheat Sheet** - Use as quick reference while studying
7. **Track Progress** - Watch your completion percentage grow!

## 🎓 Recommended Resources

### Video Courses
- [Inside Cloud & Security](https://www.youtube.com/@InsideCloudAndSecurity) - Main course
- [Professor Messer](https://www.professormesser.com/security-plus/sy0-701/sy0-701-video/sy0-701-comptia-security-plus-course/) - Supplemental videos

### Practice Questions
- [Pocket Prep](https://www.pocketprep.com/exams/comptia-security/) - Mobile app with 1000+ questions
- Daily practice exams built into this program

### Study Materials
- CompTIA Security+ SY0-701 Official Study Guide
- Practice exams and performance-based questions

## 💡 Exam Tips

- **Passing Score**: 750/900 (~83%)
- **Question Types**: Multiple choice and Performance-Based Questions (PBQs)
- **Time Management**: Do PBQs last as they're time-consuming
- **Keywords**: Pay attention to BEST, MOST, FIRST, LEAST in questions
- **Strategy**: Eliminate obviously wrong answers first

## 🛠️ Technical Details

- **Built with**: React, Tailwind CSS, Lucide Icons
- **No installation required**: Runs entirely in the browser
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Local Storage**: Progress saves automatically in your browser

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Submit bug reports
- Suggest new features
- Add more practice questions
- Improve the study materials
- Share your success story!

## 📝 License

This project is open source and available under the MIT License.

## ⭐ Success Tips

1. **Consistency is Key** - Study 3-4 hours EVERY day
2. **Don't Skip Days** - The 10-day plan is intensive by design
3. **Use Multiple Resources** - Videos, practice questions, and reading
4. **Understand, Don't Memorize** - Focus on concepts, not just facts
5. **Practice PBQs** - They're worth more points on the exam
6. **Join Study Groups** - r/CompTIA on Reddit is helpful

## 📞 Support

If you find this helpful, please ⭐ star this repository!

Found a bug? Open an issue on GitHub.

---

**Good luck on your Security+ exam! You've got this! 🎉**
