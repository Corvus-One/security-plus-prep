# 📚 BEGINNER'S GUIDE: How to Upload Your Security+ Prep App to GitHub

## 🎯 What You Need
- A GitHub account (which you already have! ✅)
- Git installed on your computer
- Your project files

---

## 📋 Step-by-Step Instructions

### OPTION 1: Upload Through GitHub Website (EASIEST - No Command Line!)

This is the simplest method if you're new to GitHub:

#### Step 1: Create a New Repository
1. Go to [github.com](https://github.com) and log in
2. Click the **"+"** button in the top-right corner
3. Select **"New repository"**

#### Step 2: Set Up Your Repository
1. **Repository name**: `security-plus-prep` (or whatever you like)
2. **Description**: "10-day Security+ exam prep study program with practice exams and video resources"
3. **Public or Private**: Choose "Public" (so others can see it) or "Private" (only you can see)
4. ✅ Check **"Add a README file"** 
5. Click **"Create repository"**

#### Step 3: Upload Your Files
1. On your new repository page, click **"Add file"** → **"Upload files"**
2. Drag and drop these files:
   - `index.html`
   - `security-plus-prep.jsx`
   - `README.md`
3. At the bottom, write a commit message like: "Initial commit - Security+ prep app"
4. Click **"Commit changes"**

#### Step 4: Enable GitHub Pages (Make it Live!)
1. In your repository, click **"Settings"** (top menu)
2. Scroll down to **"Pages"** in the left sidebar
3. Under "Source", select **"main"** branch
4. Click **"Save"**
5. Wait 1-2 minutes, then refresh - you'll see a link like:
   `https://YOUR-USERNAME.github.io/security-plus-prep/`
6. Click the link to see your live app! 🎉

---

### OPTION 2: Using Git Command Line (More Professional)

If you want to learn the proper way developers do it:

#### Step 1: Install Git
**Windows:**
- Download from [git-scm.com](https://git-scm.com/download/win)
- Run the installer (use default settings)

**Mac:**
- Open Terminal
- Type: `git --version`
- If not installed, it will prompt you to install

**Linux:**
```bash
sudo apt-get install git
```

#### Step 2: Configure Git (First Time Only)
Open Terminal (Mac/Linux) or Git Bash (Windows):
```bash
git config --global user.name "Your Name"
git config --global user.email "your-email@example.com"
```

#### Step 3: Create Repository on GitHub
1. Go to [github.com](https://github.com)
2. Click **"+"** → **"New repository"**
3. Name: `security-plus-prep`
4. Don't check "Add README" this time
5. Click **"Create repository"**
6. Copy the repository URL (looks like: `https://github.com/YOUR-USERNAME/security-plus-prep.git`)

#### Step 4: Upload Your Files
Open Terminal/Command Prompt and navigate to where your files are:

```bash
# Navigate to your project folder (example paths - adjust to your location)
cd Downloads/security-plus-prep

# Initialize Git
git init

# Add all files
git add .

# Commit your files
git commit -m "Initial commit - Security+ prep app"

# Connect to GitHub (replace YOUR-USERNAME)
git remote add origin https://github.com/YOUR-USERNAME/security-plus-prep.git

# Push to GitHub
git branch -M main
git push -u origin main
```

**Note**: If it asks for credentials:
- Username: Your GitHub username
- Password: You'll need a Personal Access Token (not your regular password)
  - Go to GitHub → Settings → Developer settings → Personal access tokens → Generate new token
  - Give it "repo" permissions
  - Copy the token and use it as your password

#### Step 5: Enable GitHub Pages
Same as Option 1, Step 4 above

---

## 📁 Files You Should Have

Make sure you have these three files in the same folder:

1. **index.html** - The main app file (can be opened directly in browser)
2. **security-plus-prep.jsx** - The React component (for reference/editing)
3. **README.md** - The description and instructions

---

## 🎨 After Upload - Customize Your Repository

### Add a Nice README Badge
Edit your README.md on GitHub and add at the top:
```markdown
![Security+ Prep](https://img.shields.io/badge/CompTIA-Security%2B-red)
![License](https://img.shields.io/badge/license-MIT-blue)
```

### Add Topics/Tags
On your repository page:
1. Click the ⚙️ gear icon next to "About"
2. Add topics: `security-plus`, `comptia`, `exam-prep`, `cybersecurity`, `study-guide`

---

## 🔄 Making Updates Later

When you want to update your app:

### Via GitHub Website:
1. Go to your repository
2. Click on the file you want to edit
3. Click the pencil ✏️ icon
4. Make changes
5. Scroll down → Add commit message → "Commit changes"

### Via Command Line:
```bash
# Make your changes to files, then:
git add .
git commit -m "Updated study plan for Day 3"
git push
```

---

## 🆘 Troubleshooting

**Problem**: "Permission denied"
- **Solution**: Make sure you're using a Personal Access Token, not your password

**Problem**: "Repository not found"
- **Solution**: Double-check the repository URL, make sure it matches exactly

**Problem**: GitHub Pages not working
- **Solution**: Wait 2-5 minutes after enabling it. Make sure index.html is in the root folder

**Problem**: Changes not showing on website
- **Solution**: Clear your browser cache (Ctrl+Shift+R or Cmd+Shift+R)

---

## 🎓 Next Steps

After uploading:
1. Share your repository URL with friends
2. Add a link to your GitHub Pages site in the README
3. Consider adding a LICENSE file (MIT is popular for open source)
4. Star your own repository to show it in your profile

---

## 📞 Need Help?

- GitHub Docs: [docs.github.com](https://docs.github.com)
- GitHub Community: [github.community](https://github.community)
- YouTube: Search "GitHub for beginners"

**Your repository URL will be**: 
`https://github.com/YOUR-USERNAME/security-plus-prep`

**Your live app URL will be**:
`https://YOUR-USERNAME.github.io/security-plus-prep/`

---

Good luck with your Security+ exam! 🎉 And welcome to GitHub! 🚀
